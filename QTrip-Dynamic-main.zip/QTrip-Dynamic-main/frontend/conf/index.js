
const config = { backendEndpoint: "https://qtrip-dynamic-qf7f.onrender.com" };

export default config;
